Cases handled:

Subscriber:
If topic is out of range(0-255), throw error.
If subscription limit (8 subscribers per topic) is reached.
If already subscribed process, tries to subscribe again, throw error.
Else allow it to subscribe.

Publisher:
If there are no current subscribers, throw error.
If Group 0, publish to all groups for that topic, else only to the topic under specified group.

Unsubscribe:
If you are not subscribed to the topic under specified group, throw error.
Else unsubscribe from the specified topic under given group

Made changes in kill.c to ensure that a subscriber unsubscribes before getting killed.

