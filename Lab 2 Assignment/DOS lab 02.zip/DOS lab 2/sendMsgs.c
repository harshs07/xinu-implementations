/* sendMsgs.c - sendMsgs */

#include <xinu.h>

/*------------------------------------------------------------------------
 *  sendMsgs  -  Pass a message to a process and start recipient if waiting
 *------------------------------------------------------------------------
 */
uint32	sendMsgs(
		pid32	pid,
		umsg32 	*msgs,
		uint32 	msg_count
	)
{	
	int i;
	intmask	mask;			/* Saved interrupt mask		*/
	struct	procent *prptr;		/* Ptr to process's table entry	*/

	mask = disable();
	if (isbadpid(pid)) {
		restore(mask);
		return SYSERR;
	}

	prptr = &proctab[pid];
	if (prptr->count==0||prptr->count>10)   {  //prptr->node->count==0) {   //Buffer full
		restore(mask);
		printf("Buffer full. Come back later\n");
		return SYSERR;
	}
	
	if (msg_count>10)   {  									  
		restore(mask);
		printf("Message block size too large\n");
		return SYSERR;
	}

	if(msg_count>prptr->count)
	{
		kprintf("Only %d out of %d messages could be succesfully sent together as of now\n",prptr->count,msg_count);
		restore(mask);		
		return (prptr->count);
	}
	
															
	kprintf("Messages successfully sent to process with pid %d:\t", (int)pid);											
	prptr->count-=msg_count;	
	i=0;													
	while(i<msg_count){	
	prptr->message[prptr->tail]=msgs[i];	
												
	prptr->tail=((prptr->tail)+1)%10;	
	kprintf("%d  ", (int)msgs[i]);
	i++;
	}
	printf("\n");

	/* If recipient waiting or in timed-wait make it ready */
	
	if (prptr->prstate == PR_RECV) {
		ready(pid);
	} else if (prptr->prstate == PR_RECTIM) {
		unsleep(pid);
		ready(pid);
	}
	restore(mask);		/* Restore interrupts */
	return msg_count;
}
