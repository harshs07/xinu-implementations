/* receiveMsg.c - receiveMsg */

#include <xinu.h>

/*------------------------------------------------------------------------
 *  receiveMsg  -  Wait for a message and return the message to the caller
 *------------------------------------------------------------------------
 */
umsg32	receiveMsg(void)
{
	intmask	mask;			/* Saved interrupt mask		*/
	struct	procent *prptr;		/* Ptr to process's table entry	*/
	umsg32	msg;			/* Message to return		*/

	mask = disable();
	prptr = &proctab[currpid];
	if (prptr->count==10) {
		kprintf("Wait for some messages to arrive:\n");					
		prptr->prstate = PR_RECV;
		resched();					
	}
			
	msg = prptr-> message[prptr->head];					
	prptr->count++; 
	prptr->head = ((prptr->head)+1)%10;	
	kprintf("Message received: %d\n",(int)msg);
	restore(mask);
	return msg;
}
