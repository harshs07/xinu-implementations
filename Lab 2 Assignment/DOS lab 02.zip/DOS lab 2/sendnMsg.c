/* sendnMsg.c - sendnMsg */

#include <xinu.h>

/*------------------------------------------------------------------------
 *  sendnMsg  -  Pass a message to n processes and start recipient if waiting
 *------------------------------------------------------------------------
 */
uint32	sendnMsg(
	  uint32  pid_count,
	  pid32	  *pids,		/* ID of recipient process	*/
	  umsg32   msg		        /* Contents of message		*/
	)
{
	intmask	mask;			/* Saved interrupt mask		*/
	int i=0,counter=0;	
	struct	procent *prptr;		/* Ptr to process's table entry	*/
	
while(pid_count--)
{	
	prptr = &proctab[pids[i]];
	mask = disable();

	if (isbadpid(pids[i])||prptr->count==0||prptr->count>10) {			/*Cannot send to this pid */
	kprintf("Cannot send to process with pid: %d\n",pids[i]);		
	}
	
	else
	{	
	prptr->count--;	
	prptr->message[prptr->tail]=msg;	
	prptr->tail=((prptr->tail)+1)%10;	
	kprintf("Message successfully sent to process with pid %d: %d\n", pids[i], (int)msg);
	counter++;

	/* If recipient waiting or in timed-wait make it ready */

	if (prptr->prstate == PR_RECV) {
		ready(pids[i]);
	} else if (prptr->prstate == PR_RECTIM) {
		unsleep(pids[i]);
		ready(pids[i]);
	}

	}
	
	i++;	
}	
	kprintf("Successfully sent to %d processes\n",counter);
	restore(mask);										/* Restore interrupts */
	return counter;
}
