/*  main.c  - main */

#include <xinu.h>

pid32 producer_id;
pid32 producer_id1;
pid32 producer_id2;
pid32 consumer_id;
pid32 consumer_id1;

process producer(void)
{	
	int i,count;
	for(i=0;i<4;i++)	
	sendMsg(consumer_id,1000+i);	
	return OK;
}

process producer1(void)
{	
	int i,count;
	umsg32 msgs[]={11,22,33,44,55,66,77,88,99};
	count=sendMsgs(consumer_id1,msgs,11);
	count=sendMsgs(consumer_id,msgs,5);
	count=sendMsgs(consumer_id1,msgs,5);	
	return OK;
}

process consumer(void)
{	
	int i;
	umsg32 msg;
	for(i=0;i<5;i++)
	msg = receiveMsg();
	return OK;
}

process consumer1(void)
{
	int i;
	umsg32 msgs[10];
		
	for(i=0;i<5;i++)
	{
	 receiveMsgs(msgs,3+i); 
	}
	
	return OK;
}

process producer2(void)
{	
	int i,count;
	pid32 pids[] = {producer_id,producer_id1,consumer_id,consumer_id1};
	count = sendnMsg(3,pids,9999);
	count = sendnMsg(4,pids,8888); 
	return OK;
}


process	main(void){

	recvclr();

	/* Create the shared circular buffer and semaphores here */
	/* */
	
	producer_id  =  create(producer, 4096, 50, "producer", 0);
	producer_id1 =  create(producer1, 4096, 50, "producer1", 0);
	producer_id2 =  create(producer2, 4096, 50, "producer2", 0);
	consumer_id  =  create(consumer, 4096, 50, "consumer", 0);
	consumer_id1 =  create(consumer1, 4096, 50, "consumer1", 0);

	resched_cntl(DEFER_START);
	
	resume(producer_id);
	resume(producer_id1);
	resume(consumer_id);
	resume(producer_id2);
	resume(consumer_id1);

	resched_cntl(DEFER_STOP);

	return OK;
}
