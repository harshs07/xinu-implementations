/* receiveMsgs.c - receiveMsgs */

#include <xinu.h>

/*------------------------------------------------------------------------------------
 *  receiveMsg  -  Wait for a group of messages and return the messages to the caller
 *------------------------------------------------------------------------------------
 */
syscall	receiveMsgs(umsg32 *msgs, uint32 msg_count)
{
	intmask	mask;			/* Saved interrupt mask		*/
	struct	procent *prptr;		/* Ptr to process's table entry	*/
	umsg32	msg;			/* Message to return		*/
	mask = disable();
	prptr = &proctab[currpid];

	if(msg_count>10){
		printf("Message block size too large\n");
		restore(mask);		
		return SYSERR;	
	}	

	while ((10-prptr->count)<msg_count) {							/* Block until message arrives	*/		
		kprintf("Not enough messages to be read currently\n");	
		prptr->prstate = PR_RECV;
		resched();					
	}
	
	int i=0;	
	kprintf("Messages received:\t");
	while(msg_count--) {
							
	msgs[i] = prptr-> message[prptr->head];								
	prptr->count++; 							
	prptr->head = ((prptr->head)+1)%10;	
	kprintf("%d\t",(int)msgs[i]);
	i++;

	}
	printf("\n");
	restore(mask);
	return OK;
}
