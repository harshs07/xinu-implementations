Functions available:

syscall sendMsg (pid32, umsg32);	  
uint32 sendMsgs (pid32, umsg32*, uint32);	  
uint32 sendnMsg (uint32, pid32*, umsg32,);	  
umsg32 receiveMsg (void);	
syscall receiveMsgs (umsg32*, uint32);


1. sendMsg()
This function sends a message to a process using the parameters (pid32,umsg32). We have assumed that each receiver has a buffer size of 10. If the buffer is full, the sender is not allowed to send and a SYSERR is returned. Else, the message is stored at the tail of the circular buffer.

2. receiveMsg()
This function returns a message at the head of the circular buffer. If the buffer is empty, it changes the receiver's state to receive state and asks it to wait until a message arrives.

3. sendMsgs()
This function sends a group or block of messages(array) to a receiver. If the block size is too large to fit, a SYSERR is returned. If only a few number of messages from the block are able to fit, a statement denoting the number of messages that could fit is printed, but partial messages are not allowed to be sent. The reason being atomicity. The rest of the messages might be dependent on the previous messages. Hence, storing partial information could be dangerous.

4. receiveMsgs()
This function takes a message block and its size to be filled with messages. If the size of requesting message block is greater than the the available messages, calling process is asked to wait until enough messages arrive. Else, the specified size of the message block is received from the queue and filled in the block provided by caller.

5. sendnMsg()
This function works like a ping or broadcast. It sends a single message to a group of receivers and specifies which ones were actually successful.
